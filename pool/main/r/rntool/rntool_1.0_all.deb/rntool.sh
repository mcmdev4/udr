#!/usr/bin/env bash

aliasname=$1
rncommand=$2

if [ "$aliasname" = "" ] && [ "$rncommand" = "" ]; then
	echo "use: rntool <aliasname> <command>"
else
	echo "alias $aliasname=""$rncommand""" | sudo tee ~/.bashrc > /dev/null
        echo "changed $rncommand to $aliasname"	
fi

